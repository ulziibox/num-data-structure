#ifndef HEADER_FILE
#define HEADER_FILE
#include <stdlib.h>

struct Stack {
	int len;
	int *dat;
	int size;
};
int error = 0;
const char error_msg[][50] = {
	"",
	"Stack duuren!",
	"Stack xooson!"
};

void init(struct Stack *p, int n)
{
	p->len = n;
	p->size = 0;
	p->dat = (int *) malloc(sizeof(int) * n);
}

void release(struct Stack *p)
{
	free(p->dat);
	p->dat = NULL;
}
/* p-ийн зааж буй Stack хоосон бол 1 үгүй бол 0-ийг буцаана */
int empty(struct Stack *p)
{
	/* Энд хоосон эсэхийг шалгах үйлдлийг хийнэ */
}

/* p-ийн зааж буй Stack-д x утгыг хийнэ */
void push(struct Stack *p, int x)
{
	/* Энд оруулах үйлдлийг хийнэ үү */
}

/* p-ийн зааж буй Stack-с гарган буцаана */
int pop(struct Stack *p)
{
	/* Энд гаргах үйлдлийг хийнэ үү */
}

/* p-ийн зааж буй Stack-н орой элементийг буцаанаутгуудыг хэвлэнэ */
int print(struct Stack *p)
{
	/* Энд орой элементийг буцаах үйлдэл хийнэ */
}


/* p-ийн зааж буй Stack-д хэдэн элемент байгааг буцаана.
   Queue-д өөрчлөлт оруулахгүй.
 */
int size(struct Stack *p)
{
	
}
